# my-bsl-http-server

A minimal HTTP web server built **from scratch** using the **Bonezegei Scripting Language (BSL)** and the **BSL Socket Library**. It listens on port `8080`, parses raw incoming HTTP requests, and routes them to one of three handlers: a home page, an about page, and a custom 404 page.

## 1. Project Description

This project demonstrates how HTTP works at a low level by building a web server without any framework — using raw TCP sockets to accept connections, read request bytes, and manually construct HTTP response headers and bodies.

The server supports the following routes:

| Route         | Method | Response         |
|---------------|--------|------------------|
| `/`           | GET    | `200 OK` — Home/landing page |
| `/about`      | GET    | `200 OK` — About page |
| Any other path (e.g. `/user`, `/xyz`) | GET | `404 Not Found` — Custom error page |

## 2. Installation & Setup Guide

### Step 1 — Install VS Code and the BSL extension
1. Open **Visual Studio Code**.
2. Go to the Extensions tab (`Ctrl+Shift+X` / `Cmd+Shift+X`).
3. Search for **"Bonezegei"** and install the **Bonezegei Scripting Language Formatter** extension.

### Step 2 — Install the BSL Interpreter
Follow the instructions bundled inside the extension:
- **Windows / Linux** — follow the native installer steps in the extension guide.
- **macOS / Android** — use **GitHub Codespaces** and follow the Linux installation process.

### Step 3 — Install the BSL Socket Library
In your terminal, run:

```bash
bzg install socket
```

### Step 4 — Clone this repository

```bash
git clone https://github.com/<your-username>/my-bsl-http-server.git
cd my-bsl-http-server
```

### Step 5 — Run the server

```bash
bzg run src/http.bzg
```

You should see:

```
Socket Ready
Server running on http://localhost:8080/
```

## 3. Usage Instructions

With the server running, open a browser and visit:

- **Home page:** [http://localhost:8080/](http://localhost:8080/)
- **About page:** [http://localhost:8080/about](http://localhost:8080/about)
- **404 page:** visit any undefined route, e.g. [http://localhost:8080/anything](http://localhost:8080/anything)

Each request is logged to the terminal (`Client connected!` and the raw request text) while the server is running.

## 4. Project Structure

```
my-bsl-http-server/
├── .gitattributes
├── LICENSE
├── README.md
├── src/
│   └── http.bzg
└── documentation/
    ├── home.png
    ├── about.png
    ├── 404.png
    └── terminal.png
```

## 5. Screenshots

> Replace the placeholders below once you've added your own screenshots to the `documentation/` folder.

### Home Route (`/`)
![Home Route](documentation/home.png)

### About Route (`/about`)
![About Route](documentation/about.png)

### 404 Route (unmapped path)
![404 Not Found](documentation/404.png)

### Terminal Output
![Terminal](documentation/terminal.png)

## 6. License

This project is licensed under the [MIT License](LICENSE).
